# ITCS4346-Lab-Project
To Do List Native Android Application, using Android Studio as a requirement for mobile computing course at AUG

**Prepared By:** Hussam Hatem Heriz

**Delivered To:** Eng. Reem Hamdan

![Screens 1](https://i.ibb.co/92FjCJT/1.png "Screens 1")

![Screens 2](https://i.ibb.co/LrBhwmd/2.png "Screens 2")

![Screens 3](https://i.ibb.co/VxVcrZ4/3.png "Screens 3")
